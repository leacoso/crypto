import fichier 
import cipher 
import csv
import timeit
import os
path_stats = "./stats_EN/"

########################################################################################################
def clear():
     os.system('cls' if os.name == 'nt' else 'clear')
########################################################################################################

def creer_stats_fit(text,cle_depart,fileNAME):
    clear()
    key=""
    global_BORN_inf=1000
    global_BORN_sup=1500 #1 paliers
    static_BORN_inf= 500
    static_BORN_sup=1000 #3 paliers
    static_BORN_inf2 = 750
    static_BORN_sup2 = 1500 #3 paliers
    
    fichier.print_progress_bar(0,global_BORN_sup, "stats fit")
    with open(fileNAME, 'w+') as csvfile:
        filewriter = csv.writer(csvfile, delimiter=',',quotechar='|', quoting=csv.QUOTE_MINIMAL)
        dictionaire1=cipher.ngram(3,path_stats)
        dictionaire2=cipher.ngram(4,path_stats)
        static1=static_BORN_inf
        static2 = static_BORN_inf2
        glob=global_BORN_inf
        while glob<=global_BORN_sup:
            static1=static_BORN_inf
            static2 = static_BORN_inf2
            while static1<=static_BORN_sup and static1 <= glob :
                
                static2 = static_BORN_inf2
                while static2 <=static_BORN_sup2 and static2 <= glob:
                
                    moyennelettres=0
                    moyennelettres2=0
                    moyennescore=0
                    moyennescore2=0
                    nb_iter=12
                    start = timeit.default_timer()
                    for i in range (0,nb_iter) :
                        key=cipher.hillClimbing(cipher.fitness1,text,dictionaire1,glob,static1,cle_depart) # 1er algo avec 1er dictionnaire
                        moyennelettres+=cipher.compare_cle(cle_de_cryptage,key)
                        key=cipher.hillClimbing(cipher.fitness1,text,dictionaire2,glob,static2,key) # 2eme algo avec 2eme dictionnaire
                        moyennelettres2+=cipher.compare_cle(cle_de_cryptage,key)
                        moyennescore+=cipher.fitness1(cipher.decipher(text,key),dictionaire1)
                        moyennescore2+=cipher.fitness1(cipher.decipher(text,key),dictionaire2)
                    stop = timeit.default_timer()
                    filewriter.writerow([str(glob),str(static1),str(static2),str(round(moyennelettres/nb_iter,2))+"/26",str(round(moyennelettres2/nb_iter,2))+"/26",str('{:.3f}'.format(moyennescore/nb_iter)),str('{:.3f}'.format(moyennescore2/nb_iter)),str('{:.3f}'.format((stop - start)/nb_iter))])
                    static2+=250
                    print("ok")
                
                static1+=250    
                    
                

            fichier.print_progress_bar(glob-global_BORN_inf, global_BORN_sup,"stats fit")
            glob+=500
    clear()
    return key

########################################################################################################

cle_de_cryptage="QASZDEFRGTHYJUKILOMPWXCVBN"
alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
text=fichier.NETTOYER_lire_fichier("./text/textCLAIRE_EN.txt")
text=cipher.encipher(text,cle_de_cryptage)
creer_stats_fit(text,alphabet,"./stats_GEN/fit.csv")

